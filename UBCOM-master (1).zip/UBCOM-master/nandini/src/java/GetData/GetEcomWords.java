/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GetData;

import java.io.*;
import java.util.*;


public class GetEcomWords {
    public ArrayList<String> allPosEcomWords = new ArrayList<String>();
public ArrayList<String> allNegEcomWords = new ArrayList<String>();

public ArrayList<String> getAllPosEcomWordsFromTweet(String tweet){
    allPosEcomWords.clear();
    try{
     FileInputStream fis = new FileInputStream("");   
    }catch(Exception e){
        System.out.println(e);
    }
    return allPosEcomWords;
}
    
}
