
public class Testing {
    
    public static void main(String []args){
        String str = "modi is not good";
        
        System.out.println(str.contains("not good"));
        
    }
    
}
